//not comma but simicolon as member values
// type User = {
//   id:string;
//   avatar:string;
//   name:string;
// }
export interface User {
    id:string;
    avatar:string;
    name:string;
  }