export interface InvestmenInput{
    initialInvestment: number,
    duration: number,
    expectedReturn: number,
    annualInvestment : number,
}

// export type InvestmenInput{
//     initialInvestment: number,
//     duration: number,
//     expectedReturn: number,
//     annualInvestment : number,
// }